java -cp pocminer_pool.jar:lib/*:lib/akka/*:lib/jetty/* pocminer_pool.POCMiner $@

