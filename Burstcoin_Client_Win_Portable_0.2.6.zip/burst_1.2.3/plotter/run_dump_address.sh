java -cp pocminer.jar:lib/*:lib/akka/*:lib/jetty/* pocminer.POCMiner dumpaddr >address.txt
