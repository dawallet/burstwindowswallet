POCMiner_pool v1

This is almost the same as regular pocminer. mine now takes second address for a pool. Network status is read from the pool. plot files that have a corresponding passphrase are solo mined to the local wallet if running, and plot files where passphrases cannot be found are assumed to be for the pool.
edit the pool ip into the mine.bat and run that to mine.
