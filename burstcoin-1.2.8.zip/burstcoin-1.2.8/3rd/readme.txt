binaries by Juraj Michalak 
http://www.latenighthacking.com/projects/2003/sendsignal/

Check:

https://www.virustotal.com/de/file/29711209fed703199c7cc75b402e10708cdaaec9169a0b297167588308b3b58e/analysis/

https://www.virustotal.com/de/file/bdd0a7c3f14d1105a81cbb32d75762dd948da10bb227bf27c9c4ff09654ee8a3/analysis/