java -Xmx4000m -cp pocminer.jar:lib/*:lib/akka/*:lib/jetty/* pocminer.POCMiner generate $@
