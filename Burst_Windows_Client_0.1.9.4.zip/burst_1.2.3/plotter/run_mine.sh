java -Xmx750m -cp pocminer.jar:lib/*:lib/akka/*:lib/jetty/* pocminer.POCMiner mine "http://127.0.0.1:8125"

